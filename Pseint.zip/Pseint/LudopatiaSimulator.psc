// =====================================================================
//   LUDOPATIA SIMULATOR
//   Integrantes: Federico Kusbyt y Mateo Rodriguez
// =====================================================================

// ---------- Interfaz ----------

Funcion r <- lineaDoble
	r <- "+====================================+"
FinFuncion

Funcion r <- lineaSimple
	r <- "+------------------------------------+"
FinFuncion

// Arma un texto repitiendo "marca" la cantidad de veces indicada
Funcion r <- armar(marca, cantidad)
	Definir i Como Entero
	r <- ""
	Para i <- 1 Hasta cantidad Hacer
		r <- r + marca
	FinPara
FinFuncion

// Agrega espacios a la derecha hasta llegar al ancho indicado
Funcion r <- rellenar(frase, ancho)
	r <- frase
	Mientras Longitud(r) < ancho Hacer
		r <- r + " "
	FinMientras
FinFuncion

// Centra un texto dentro de un ancho fijo
Funcion r <- centrar(frase, ancho)
	r <- rellenar(armar(" ", trunc((ancho - Longitud(frase)) / 2)) + frase, ancho)
FinFuncion

// Muestra un numero con 2 decimales (por ejemplo 1500.50)
Funcion r <- dinero(valor)
	Definir enteros, centavos Como Entero
	enteros <- trunc(valor)
	centavos <- redon((valor - enteros) * 100)
	Si centavos = 100 Entonces
		enteros <- enteros + 1
		centavos <- 0
	FinSi
	r <- ConvertirATexto(enteros) + "."
	Si centavos < 10 Entonces
		r <- r + "0"
	FinSi
	r <- r + ConvertirATexto(centavos)
FinFuncion

// Titulo centrado dentro de una caja
SubProceso mostrarTitulo(frase)
	Escribir lineaDoble()
	Escribir "|", centrar(frase, 36), "|"
	Escribir lineaDoble()
FinSubProceso

// Una linea de texto dentro de la caja (hasta 34 caracteres)
SubProceso mostrarLinea(frase)
	Escribir "| ", rellenar(frase, 34), " |"
FinSubProceso

// Una linea con dos columnas: texto a la izquierda y dato a la derecha
SubProceso mostrarLinea2(izquierda, derecha)
	Escribir "| ", rellenar(izquierda, 22), " ", rellenar(derecha, 11), " |"
FinSubProceso

// Espera una tecla y limpia la pantalla
SubProceso aguardarTecla(mensaje)
	Escribir ""
	Escribir Sin Saltar "  ", mensaje
	Esperar Tecla
	Limpiar Pantalla
FinSubProceso

// Pantalla intermedia: resumen de la apuesta antes de mostrar el resultado
SubProceso pantallaApuesta(titulo, apuesta, detalle, accion)
	Limpiar Pantalla
	mostrarTitulo(titulo)
	mostrarLinea("Apuesta: $" + ConvertirATexto(apuesta))
	mostrarLinea(detalle)
	Escribir lineaDoble()
	aguardarTecla("Presiona una tecla para " + accion + "...")
FinSubProceso

// Cartel con el resultado de cualquier juego (neto > 0 gana, < 0 pierde)
SubProceso mostrarResultado(neto, nota)
	Definir linea Como Caracter
	Si neto > 0 Entonces
		linea <- ">> GANASTE $" + dinero(neto)
	Sino
		Si neto < 0 Entonces
			linea <- ">> PERDISTE $" + dinero(-neto)
		Sino
			linea <- ">> NO GANASTE NI PERDISTE"
		FinSi
	FinSi
	Escribir ""
	Escribir lineaDoble()
	mostrarLinea(linea)
	Si Longitud(nota) > 0 Entonces
		mostrarLinea(nota)
	FinSi
	Escribir lineaDoble()
FinSubProceso

// ---------- Ingreso de datos ----------

// Devuelve Verdadero si el texto tiene solo digitos (y no esta vacio)
Funcion r <- soloNumeros(frase)
	Definir i, j Como Entero
	Definir esDigito Como Logico
	r <- Longitud(frase) > 0
	Para i <- 1 Hasta Longitud(frase) Hacer
		esDigito <- Falso
		Para j <- 1 Hasta 10 Hacer
			Si Subcadena(frase, i, i) = Subcadena("0123456789", j, j) Entonces
				esDigito <- Verdadero
			FinSi
		FinPara
		Si esDigito = Falso Entonces
			r <- Falso
		FinSi
	FinPara
FinFuncion

// Pide un numero entero entre minimo y maximo y vuelve a preguntar si es invalido.
// Si puedeVolver vale 1, el usuario tambien puede escribir V para arrepentirse (devuelve -1)
Funcion valor <- leerNumero(mensaje, minimo, maximo, puedeVolver)
	Definir linea Como Caracter
	Definir listo Como Logico
	valor <- 0
	listo <- Falso
	Mientras listo = Falso Hacer
		Escribir Sin Saltar mensaje
		Leer linea
		Si puedeVolver = 1 Y Mayusculas(linea) = "V" Entonces
			valor <- -1
			listo <- Verdadero
		Sino
			Si soloNumeros(linea) = Falso Entonces
				Escribir ">> Error: tenes que ingresar solo numeros (sin letras, espacios ni simbolos)."
			Sino
				Si Longitud(linea) > 6 Entonces
					valor <- minimo - 1
				Sino
					valor <- ConvertirANumero(linea)
				FinSi
				Si valor < minimo O valor > maximo Entonces
					Escribir ">> Error: el valor tiene que estar entre ", minimo, " y ", maximo, "."
				Sino
					listo <- Verdadero
				FinSi
			FinSi
		FinSi
	FinMientras
FinFuncion

// Muestra el saldo y pide el monto a apostar (V para volver)
Funcion valor <- pedirMonto(saldo)
	Escribir "  Tu saldo: $", dinero(saldo)
	valor <- leerNumero("Monto a apostar: $", 1, trunc(saldo), 1)
FinFuncion

// Pide el nombre hasta que no este vacio ni tenga numeros
Funcion nombre <- leerNombre
	Definir i, j Como Entero
	Definir tieneNumero, listo Como Logico
	listo <- Falso
	Mientras listo = Falso Hacer
		Escribir Sin Saltar "Nombre: "
		Leer nombre
		tieneNumero <- Falso
		Para i <- 1 Hasta Longitud(nombre) Hacer
			Para j <- 1 Hasta 10 Hacer
				Si Subcadena(nombre, i, i) = Subcadena("0123456789", j, j) Entonces
					tieneNumero <- Verdadero
				FinSi
			FinPara
		FinPara
		Si Longitud(nombre) = 0 Entonces
			Escribir ">> Error: el nombre no puede estar vacio."
		Sino
			Si tieneNumero = Verdadero Entonces
				Escribir ">> Error: el nombre no puede tener numeros."
			Sino
				listo <- Verdadero
			FinSi
		FinSi
	FinMientras
FinFuncion

// ---------- Dados ----------

// Una fila (0 a 2) de la cara de un dado. Cada cara es un numero de 9 bits:
// cada bit encendido es un punto en la grilla de 3x3 del dado.
Funcion r <- filaDado(cara, fila)
	Definir mascara, columna, bit Como Entero
	Segun cara Hacer
		1: mascara <- 16
		2: mascara <- 257
		3: mascara <- 273
		4: mascara <- 325
		5: mascara <- 341
		6: mascara <- 365
	FinSegun
	r <- " "
	Para columna <- 0 Hasta 2 Hacer
		bit <- fila * 3 + columna
		Si trunc(mascara / 2 ^ bit) MOD 2 = 1 Entonces
			r <- r + "O "
		Sino
			r <- r + "  "
		FinSi
	FinPara
FinFuncion

SubProceso mostrarDados(d1, d2)
	Definir f Como Entero
	Escribir "   +-------+   +-------+"
	Escribir "   |       |   |       |"
	Para f <- 0 Hasta 2 Hacer
		Escribir "   |", filaDado(d1, f), "|   |", filaDado(d2, f), "|"
	FinPara
	Escribir "   |       |   |       |"
	Escribir "   +-------+   +-------+"
FinSubProceso

// Animacion: los dados ruedan y se van frenando hasta mostrar el resultado
SubProceso tirarDados(d1, d2)
	Definir i, pausa Como Entero
	Para i <- 0 Hasta 9 Hacer
		Limpiar Pantalla
		mostrarTitulo("DADOS")
		Escribir ""
		Si i < 9 Entonces
			mostrarDados(Aleatorio(1, 6), Aleatorio(1, 6))
		Sino
			mostrarDados(d1, d2)
		FinSi
		pausa <- 80 + i * 25
		Esperar pausa Milisegundos
	FinPara
FinSubProceso

// Nombre de cada opcion de los modos 2 y 3
Funcion r <- nombreDeEleccion(modo, eleccion)
	Si modo = 2 Entonces
		Si eleccion = 1 Entonces
			r <- "Par"
		Sino
			r <- "Impar"
		FinSi
	Sino
		Si eleccion = 1 Entonces
			r <- "Menor a 7 (2-6)"
		Sino
			r <- "Mayor a 7 (8-12)"
		FinSi
	FinSi
FinFuncion

// Tira los dados y devuelve lo que se gano (positivo) o perdio (negativo)
Funcion neto <- resolverDados(modo, apuesta, objetivo, eleccion, detalle)
	Definir pago, d1, d2, suma Como Entero
	Definir gano Como Logico
	Definir nota Como Caracter
	pago <- 2
	Si modo = 1 Entonces
		pago <- 10
	FinSi
	pantallaApuesta("DADOS", apuesta, detalle, "tirar los dados")

	d1 <- Aleatorio(1, 6)
	d2 <- Aleatorio(1, 6)
	suma <- d1 + d2
	tirarDados(d1, d2)
	Escribir ""
	Escribir "          SUMA = ", suma

	gano <- Falso
	Si modo = 1 Y suma = objetivo Entonces
		gano <- Verdadero
	FinSi
	Si modo = 2 Y ((eleccion = 1 Y suma MOD 2 = 0) O (eleccion = 2 Y suma MOD 2 = 1)) Entonces
		gano <- Verdadero
	FinSi
	Si modo = 3 Y ((eleccion = 1 Y suma < 7) O (eleccion = 2 Y suma > 7)) Entonces
		gano <- Verdadero
	FinSi

	// Evento especial: con dobles no se pierde la apuesta
	nota <- ""
	Si d1 = d2 Entonces
		nota <- "DOBLE VIDA: con dobles no perdes"
	FinSi
	Si gano = Verdadero Entonces
		neto <- apuesta * (pago - 1)
	Sino
		Si d1 = d2 Entonces
			neto <- 0
		Sino
			neto <- -apuesta
		FinSi
	FinSi
	mostrarResultado(neto, nota)
FinFuncion

// Pide los datos de la apuesta. Si el usuario escribe V, devuelve 1000000000 (no se jugo)
Funcion neto <- jugarDados(saldo)
	Definir modo, apuesta, objetivo, eleccion Como Entero
	Definir volvio Como Logico
	Definir detalle, pregunta Como Caracter
	objetivo <- 0
	eleccion <- 0
	apuesta <- 0
	detalle <- ""
	volvio <- Falso

	Limpiar Pantalla
	mostrarTitulo("DADOS")
	mostrarLinea("MODOS DE JUEGO")
	Escribir lineaSimple()
	mostrarLinea2("1) Suma exacta", "(paga x10)")
	mostrarLinea2("2) Par o impar", "(paga x2)")
	mostrarLinea2("3) Mayor o menor a 7", "(paga x2)")
	Escribir lineaSimple()
	mostrarLinea("V) Volver al menu")
	Escribir lineaDoble()
	Escribir ""

	modo <- leerNumero("Elegi el modo: ", 1, 3, 1)
	Si modo = -1 Entonces
		volvio <- Verdadero
	FinSi
	Si volvio = Falso Entonces
		apuesta <- pedirMonto(saldo)
		Si apuesta = -1 Entonces
			volvio <- Verdadero
		FinSi
	FinSi
	Si volvio = Falso Entonces
		Si modo = 1 Entonces
			objetivo <- leerNumero("A que suma apostas (2-12): ", 2, 12, 1)
			detalle <- "Suma exacta: " + ConvertirATexto(objetivo)
			Si objetivo = -1 Entonces
				volvio <- Verdadero
			FinSi
		Sino
			pregunta <- "Elegis: 1) "
			pregunta <- pregunta + nombreDeEleccion(modo, 1)
			pregunta <- pregunta + "  2) "
			pregunta <- pregunta + nombreDeEleccion(modo, 2)
			pregunta <- pregunta + ": "
			eleccion <- leerNumero(pregunta, 1, 2, 1)
			Si eleccion = -1 Entonces
				volvio <- Verdadero
			Sino
				detalle <- "Elegiste: " + nombreDeEleccion(modo, eleccion)
			FinSi
		FinSi
	FinSi

	Si volvio = Verdadero Entonces
		neto <- 1000000000
	Sino
		neto <- resolverDados(modo, apuesta, objetivo, eleccion, detalle)
	FinSi
FinFuncion

// ---------- Tragamonedas ----------

// Simbolos de los rodillos (numero 1 a 5)
Funcion r <- simbolo(n)
	r <- Subcadena("$#@&7", n, n)
FinFuncion

SubProceso mostrarTragamonedas(n1, n2, n3)
	Escribir lineaDoble()
	Escribir "|    *   *   TRAGAMONEDAS   *   *    |"
	Escribir lineaDoble()
	Escribir "|                                    |"
	Escribir "|    +-------+ +-------+ +-------+   |"
	Escribir "|    |       | |       | |       |   |"
	Escribir "|    |   ", simbolo(n1), "   | |   ", simbolo(n2), "   | |   ", simbolo(n3), "   |   |"
	Escribir "|    |       | |       | |       |   |"
	Escribir "|    +-------+ +-------+ +-------+   |"
	Escribir "|                                    |"
	Escribir lineaDoble()
FinSubProceso

// Animacion: los rodillos giran y se frenan de a uno
SubProceso girarTragamonedas(n1, n2, n3)
	Definir i, r1, r2, r3 Como Entero
	Para i <- 0 Hasta 12 Hacer
		r1 <- n1
		r2 <- n2
		r3 <- n3
		Si i < 5 Entonces
			r1 <- Aleatorio(1, 5)
		FinSi
		Si i < 8 Entonces
			r2 <- Aleatorio(1, 5)
		FinSi
		Si i < 12 Entonces
			r3 <- Aleatorio(1, 5)
		FinSi
		Limpiar Pantalla
		mostrarTragamonedas(r1, r2, r3)
		Esperar 120 Milisegundos
	FinPara
FinSubProceso

// Tira de la palanca y devuelve lo que se gano (positivo) o perdio (negativo)
Funcion neto <- resolverTragamonedas(apuesta)
	Definir n1, n2, n3 Como Entero
	Definir nota Como Caracter
	nota <- ""
	pantallaApuesta("TRAGAMONEDAS", apuesta, "Tres rodillos: $ # @ & 7", "tirar de la palanca")

	n1 <- Aleatorio(1, 5)
	n2 <- Aleatorio(1, 5)
	n3 <- Aleatorio(1, 5)
	girarTragamonedas(n1, n2, n3)

	Si n1 = n2 Y n2 = n3 Entonces
		neto <- apuesta * 5
		nota <- "PREMIO MAYOR!"
	Sino
		Si n1 = n2 O n2 = n3 O n1 = n3 Entonces
			neto <- apuesta * 1.5
		Sino
			neto <- -apuesta
		FinSi
	FinSi
	mostrarResultado(neto, nota)
FinFuncion

Funcion neto <- jugarTragamonedas(saldo)
	Definir apuesta Como Entero

	Limpiar Pantalla
	mostrarTitulo("TRAGAMONEDAS")
	mostrarLinea("PREMIOS")
	Escribir lineaSimple()
	mostrarLinea2("3 simbolos iguales", "paga x5")
	mostrarLinea2("2 simbolos iguales", "paga x1.5")
	mostrarLinea2("Todos distintos", "perdes")
	Escribir lineaSimple()
	mostrarLinea("V) Volver al menu")
	Escribir lineaDoble()
	Escribir ""

	apuesta <- pedirMonto(saldo)
	Si apuesta = -1 Entonces
		neto <- 1000000000
	Sino
		neto <- resolverTragamonedas(apuesta)
	FinSi
FinFuncion

// ---------- Ruleta animada ----------
// La rueda se dibuja en una matriz de 25 filas x 67 columnas (letra por letra).
// Las posiciones se cuentan desde 0: columna 0 a 66, fila 0 a 24.
// El centro de la rueda esta en la columna 33, fila 12.

// Devuelve 0 = verde, 1 = rojo, 2 = negro
Funcion r <- colorDe(num)
	Definir i Como Entero
	Definir rojos Como Caracter
	rojos <- "010305070912141618192123252730323436"
	r <- 2
	Si num = 0 Entonces
		r <- 0
	FinSi
	Para i <- 1 Hasta 18 Hacer
		Si ConvertirANumero(Subcadena(rojos, 2 * i - 1, 2 * i)) = num Entonces
			r <- 1
		FinSi
	FinPara
FinFuncion

Funcion r <- nombreColor(num)
	Segun colorDe(num) Hacer
		0: r <- "VERDE"
		1: r <- "ROJO"
		2: r <- "NEGRO"
	FinSegun
FinFuncion

// Escribe por ejemplo: "17 - NEGRO - IMPAR"
Funcion r <- descripcion(num)
	r <- ConvertirATexto(num) + " - " + nombreColor(num)
	Si num <> 0 Entonces
		Si num MOD 2 = 0 Entonces
			r <- r + " - PAR"
		Sino
			r <- r + " - IMPAR"
		FinSi
	FinSi
FinFuncion

// Escribe un texto en la matriz, desde la columna "colum" de la fila "fil"
SubProceso poner(g, colum, fil, frase)
	Definir k Como Entero
	Para k <- 1 Hasta Longitud(frase) Hacer
		Si fil >= 0 Y fil < 25 Y colum + k - 1 >= 0 Y colum + k - 1 < 67 Entonces
			g[fil + 1, colum + k] <- Subcadena(frase, k, k)
		FinSi
	FinPara
FinSubProceso

SubProceso elipse(g, rx, ry, marca)
	Definir i, colum, fil Como Entero
	Para i <- 0 Hasta 719 Hacer
		colum <- 33 + redon(rx * sen(i * PI / 360))
		fil <- 12 - redon(ry * cos(i * PI / 360))
		poner(g, colum, fil, marca)
	FinPara
FinSubProceso

// Posicion del numero k (1 a 37) de la rueda: columna = 0, fila = 1
Funcion r <- posicionNumero(k, cual)
	Definir angulo Como Real
	angulo <- 2 * PI * (k - 1) / 37
	Si cual = 0 Entonces
		r <- 33 + redon(26 * sen(angulo))
	Sino
		r <- 12 - redon(10 * cos(angulo))
	FinSi
FinFuncion

// Texto centrado dentro de la caja del centro (13 de ancho)
SubProceso centrado(g, fil, frase)
	poner(g, 27, fil, centrar(frase, 13))
FinSubProceso

// Dibuja la rueda completa sin la bolita (se hace una sola vez)
SubProceso dibujarRueda(base, orden)
	Definir i, j, k Como Entero
	Para i <- 1 Hasta 25 Hacer
		Para j <- 1 Hasta 67 Hacer
			base[i, j] <- " "
		FinPara
	FinPara
	elipse(base, 30, 12, "*")
	elipse(base, 22, 8, ".")
	Para k <- 1 Hasta 37 Hacer
		Si orden[k] < 10 Entonces
			poner(base, posicionNumero(k, 0) - 1, posicionNumero(k, 1), " " + ConvertirATexto(orden[k]))
		Sino
			poner(base, posicionNumero(k, 0) - 1, posicionNumero(k, 1), ConvertirATexto(orden[k]))
		FinSi
	FinPara
	poner(base, 26, 10, "+-------------+")
	Para k <- 11 Hasta 13 Hacer
		poner(base, 26, k, "|             |")
	FinPara
	poner(base, 26, 14, "+-------------+")
FinSubProceso

// Arma un cuadro de la animacion y lo muestra.
// frame: posicion de la bolita (0 a 7)   casillero: 0 si todavia gira, o el casillero ganador (1 a 37)
// tiempo: ms transcurridos               brillo: 1 hace parpadear el numero ganador
SubProceso mostrarRuleta(base, pant, orden, frame, casillero, tiempo, brillo)
	Definir i, j, num, decimas Como Entero
	Definir angulo Como Real
	Definir fila, frase, barra Como Caracter

	Para i <- 1 Hasta 25 Hacer
		Para j <- 1 Hasta 67 Hacer
			pant[i, j] <- base[i, j]
		FinPara
	FinPara

	// Rayos que giran en el centro
	Para i <- 0 Hasta 3 Hacer
		Para j <- 9 Hasta 15 Hacer
			angulo <- frame * PI / 4 + i * PI / 2
			poner(pant, 33 + redon(22 * j / 20 * sen(angulo)), 12 - redon(8 * j / 20 * cos(angulo)), ".")
		FinPara
	FinPara

	// La bolita: 8 posiciones al girar, o el casillero ganador al final
	Si casillero > 0 Entonces
		angulo <- 2 * PI * (casillero - 1) / 37
	Sino
		angulo <- 2 * PI * frame / 8
	FinSi
	poner(pant, 33 + redon(22 * sen(angulo)), 12 - redon(8 * cos(angulo)), "O")

	// Texto del centro y parpadeo del ganador
	Si casillero > 0 Entonces
		num <- orden[casillero]
		centrado(pant, 11, "RESULTADO")
		centrado(pant, 12, ConvertirATexto(num))
		centrado(pant, 13, nombreColor(num))
		Si brillo = 1 Entonces
			poner(pant, posicionNumero(casillero, 0) - 2, posicionNumero(casillero, 1), "[")
			poner(pant, posicionNumero(casillero, 0) + 1, posicionNumero(casillero, 1), "]")
		FinSi
	Sino
		centrado(pant, 11, "GIRANDO...")
		centrado(pant, 12, "?")
	FinSi

	// Mostrar la rueda
	Limpiar Pantalla
	Para i <- 1 Hasta 25 Hacer
		fila <- ""
		Para j <- 1 Hasta 67 Hacer
			fila <- fila + pant[i, j]
		FinPara
		Escribir fila
	FinPara

	// Panel de abajo: barra de progreso o informe final
	Escribir " +", armar("-", 63), "+"
	Si casillero > 0 Entonces
		frase <- "SALIO EL " + descripcion(num)
	Sino
		barra <- ""
		Para i <- 1 Hasta 30 Hacer
			Si i <= trunc(tiempo * 30 / 7000) Entonces
				barra <- barra + "#"
			Sino
				barra <- barra + "-"
			FinSi
		FinPara
		decimas <- trunc(tiempo / 100)
		frase <- "GIRANDO...  [" + barra + "]  " + ConvertirATexto(trunc(decimas / 10)) + "." + ConvertirATexto(decimas MOD 10) + "s / 7s"
	FinSi
	Escribir " |", centrar(frase, 63), "|"
	Escribir " +", armar("-", 63), "+"
FinSubProceso

// La ruleta gira 3 s a velocidad fija y frena durante 4 s: la bolita cae a los 7 s
SubProceso animarRuleta(numero)
	Definir i, tiempo, casillero, pausa Como Entero
	Definir orden Como Entero
	Definir base, pant Como Caracter
	Definir ordenado, pausas Como Caracter
	Dimension orden[37], base[25, 67], pant[25, 67]

	// Numeros en el orden real de la ruleta europea (de a dos cifras)
	ordenado <- "0032151904210225173406271336113008231005241633012014310922182907281235 03 26"
	ordenado <- "00" + "32" + "15" + "19" + "04" + "21" + "02" + "25" + "17" + "34" + "06" + "27" + "13" + "36" + "11" + "30" + "08" + "23" + "10" + "05" + "24" + "16" + "33" + "01" + "20" + "14" + "31" + "09" + "22" + "18" + "29" + "07" + "28" + "12" + "35" + "03" + "26"
	Para i <- 1 Hasta 37 Hacer
		orden[i] <- ConvertirANumero(Subcadena(ordenado, 2 * i - 1, 2 * i))
	FinPara

	casillero <- 1
	Mientras orden[casillero] <> numero Hacer
		casillero <- casillero + 1
	FinMientras

	dibujarRueda(base, orden)

	// Pausas de cada cuadro: 12 a velocidad fija y 10 frenando (en total 7 segundos)
	pausas <- "250270300330370410450500550570"
	tiempo <- 0
	Para i <- 1 Hasta 22 Hacer
		mostrarRuleta(base, pant, orden, (i - 1) MOD 8, 0, tiempo, 0)
		Si i <= 12 Entonces
			pausa <- 250
		Sino
			pausa <- ConvertirANumero(Subcadena(pausas, 3 * (i - 12) - 2, 3 * (i - 12)))
		FinSi
		Esperar pausa Milisegundos
		tiempo <- tiempo + pausa
	FinPara

	// La bolita cae en el casillero ganador y el numero parpadea
	Para i <- 0 Hasta 12 Hacer
		mostrarRuleta(base, pant, orden, 0, casillero, tiempo, 1 - i MOD 2)
		Esperar 250 Milisegundos
	FinPara
FinSubProceso

// Formulario de la ruleta: muestra lo ya elegido, cada dato en su renglon
SubProceso fichaRuleta(tipoApuesta, apuesta)
	Definir linea Como Caracter
	Limpiar Pantalla
	mostrarTitulo("RULETA")
	mostrarLinea("TU APUESTA")
	Escribir lineaSimple()
	mostrarLinea("Tipo de apuesta: " + tipoApuesta)
	Si apuesta > 0 Entonces
		linea <- "Monto: $" + ConvertirATexto(apuesta)
	Sino
		linea <- "Monto: ..."
	FinSi
	mostrarLinea(linea)
	Escribir lineaSimple()
	mostrarLinea("V) Volver al menu")
	Escribir lineaDoble()
	Escribir ""
FinSubProceso

// Gira la ruleta y muestra el resultado de la apuesta
Funcion neto <- resolverRuleta(apuesta, tipoApuesta, eleccion, detalle)
	Definir num Como Entero
	Definir gano Como Logico
	Definir nota Como Caracter
	pantallaApuesta("RULETA", apuesta, detalle, "girar la ruleta")

	// Gira la ruleta y despues se muestra el resultado de la apuesta
	num <- Aleatorio(0, 36)
	animarRuleta(num)
	aguardarTecla("Presiona una tecla para ver tu resultado...")

	mostrarTitulo("RULETA")
	mostrarLinea("Salio el " + descripcion(num))
	mostrarLinea("Apuesta: $" + ConvertirATexto(apuesta))
	mostrarLinea(detalle)
	Escribir lineaDoble()

	gano <- Falso
	Si tipoApuesta = 1 Y eleccion = num Entonces
		gano <- Verdadero
	FinSi
	Si num <> 0 Y tipoApuesta = 2 Y ((eleccion = 1 Y colorDe(num) = 1) O (eleccion = 2 Y colorDe(num) = 2)) Entonces
		gano <- Verdadero
	FinSi
	Si num <> 0 Y tipoApuesta = 3 Y ((eleccion = 1 Y num MOD 2 = 0) O (eleccion = 2 Y num MOD 2 = 1)) Entonces
		gano <- Verdadero
	FinSi

	// Si sale el 0 (verde) no se pierde la apuesta de color ni la de par/impar
	nota <- ""
	Si num = 0 Y tipoApuesta <> 1 Entonces
		nota <- "Salio el 0: no perdes tu apuesta"
	FinSi
	Si gano = Verdadero Entonces
		Si tipoApuesta = 1 Entonces
			neto <- apuesta * 35
		Sino
			neto <- apuesta
		FinSi
	Sino
		Si num = 0 Y tipoApuesta <> 1 Entonces
			neto <- 0
		Sino
			neto <- -apuesta
		FinSi
	FinSi
	mostrarResultado(neto, nota)
FinFuncion

// Pide los datos de la apuesta. Si el usuario escribe V, devuelve 1000000000 (no se jugo)
Funcion neto <- jugarRuleta(saldo)
	Definir apuesta, tipoApuesta, eleccion, minimo, maximo Como Entero
	Definir volvio Como Logico
	Definir detalle, nombreTipo, pregunta Como Caracter
	apuesta <- 0
	eleccion <- 0
	detalle <- ""
	volvio <- Falso

	Limpiar Pantalla
	mostrarTitulo("RULETA")
	mostrarLinea("TIPOS DE APUESTA")
	Escribir lineaSimple()
	mostrarLinea2("1) Numero exacto", "(paga x35)")
	mostrarLinea2("2) Rojo o negro", "(paga x1)")
	mostrarLinea2("3) Par o impar", "(paga x1)")
	Escribir lineaSimple()
	mostrarLinea("Si sale el 0 (verde) no se pierde")
	mostrarLinea("la apuesta de color ni par/impar")
	Escribir lineaSimple()
	mostrarLinea("V) Volver al menu")
	Escribir lineaDoble()
	Escribir ""

	tipoApuesta <- leerNumero("Tipo de apuesta: ", 1, 3, 1)
	Si tipoApuesta = -1 Entonces
		volvio <- Verdadero
	FinSi

	Si volvio = Falso Entonces
		Segun tipoApuesta Hacer
			1:
				nombreTipo <- "Numero exacto"
				pregunta <- "Numero elegido (0-36): "
				minimo <- 0
				maximo <- 36
			2:
				nombreTipo <- "Rojo o negro"
				pregunta <- "Color: 1) Rojo  2) Negro: "
				minimo <- 1
				maximo <- 2
			3:
				nombreTipo <- "Par o impar"
				pregunta <- "Elegis: 1) Par  2) Impar: "
				minimo <- 1
				maximo <- 2
		FinSegun
		fichaRuleta(nombreTipo, 0)
		apuesta <- pedirMonto(saldo)
		Si apuesta = -1 Entonces
			volvio <- Verdadero
		FinSi
	FinSi

	Si volvio = Falso Entonces
		fichaRuleta(nombreTipo, apuesta)
		eleccion <- leerNumero(pregunta, minimo, maximo, 1)
		Si eleccion = -1 Entonces
			volvio <- Verdadero
		FinSi
	FinSi

	Si volvio = Falso Entonces
		Si tipoApuesta = 1 Entonces
			detalle <- "Numero exacto: " + ConvertirATexto(eleccion)
		Sino
			Si tipoApuesta = 2 Entonces
				Si eleccion = 1 Entonces
					detalle <- "Color: Rojo"
				Sino
					detalle <- "Color: Negro"
				FinSi
			Sino
				Si eleccion = 1 Entonces
					detalle <- "Elegiste: Par"
				Sino
					detalle <- "Elegiste: Impar"
				FinSi
			FinSi
		FinSi
	FinSi

	Si volvio = Verdadero Entonces
		neto <- 1000000000
	Sino
		neto <- resolverRuleta(apuesta, tipoApuesta, eleccion, detalle)
	FinSi
FinFuncion

// ---------- Comprobante final ----------

// Una fila de la caja de dos columnas
SubProceso mostrarFila2(izquierda, derecha)
	Escribir "| ", rellenar(izquierda, 28), " | ", rellenar(derecha, 29), " |"
FinSubProceso

// Comprobante: a la izquierda las partidas de cada juego y a la derecha la plata ganada o perdida
SubProceso mostrarComprobante(nombre, saldo, jugadas, total)
	Definir i, j Como Entero
	Definir izquierda, derecha Como Caracter
	Escribir "+", armar("=", 62), "+"
	Escribir "|", centrar("COMPROBANTE FINAL - LUDOPATIA SIMULATOR", 62), "|"
	Escribir "+", armar("=", 30), "+", armar("=", 31), "+"
	mostrarFila2("Registro Partidas", "Registro Saldo")
	mostrarFila2("", "")
	Para i <- 1 Hasta 3 Hacer
		// se muestra: Ruleta, Dados, Tragamonedas
		Segun i Hacer
			1: j <- 3
			2: j <- 1
			3: j <- 2
		FinSegun
		izquierda <- nombreJuego(j) + ": " + ConvertirATexto(jugadas[j])
		Si total[j] >= 0 Entonces
			derecha <- "Ganancia: $" + dinero(total[j])
		Sino
			derecha <- "Perdida: $" + dinero(-total[j])
		FinSi
		mostrarFila2(izquierda, derecha)
	FinPara
	Escribir "+", armar("-", 30), "+", armar("-", 31), "+"
	mostrarFila2("Jugador: " + Subcadena(nombre, 1, 18), "Saldo final: $" + dinero(saldo))
	Escribir "+", armar("=", 30), "+", armar("=", 31), "+"
FinSubProceso

// ---------- Programa principal ----------

Funcion r <- nombreJuego(n)
	Segun n Hacer
		1: r <- "Dados"
		2: r <- "Tragamonedas"
		3: r <- "Ruleta"
	FinSegun
FinFuncion

Algoritmo LudopatiaSimulator
	Definir nombre, linea Como Caracter
	Definir edad, seleccion, saldoInicial, i Como Entero
	Definir saldo, resultado Como Real
	Definir jugadas Como Entero
	Definir total Como Real
	Dimension jugadas[3], total[3]

	Para i <- 1 Hasta 3 Hacer
		jugadas[i] <- 0
		total[i] <- 0
	FinPara

	// ----- Cartel inicial -----
	mostrarTitulo("LUDOPATIA SIMULATOR")
	aguardarTecla("Presiona cualquier tecla para continuar...")

	// ----- Inscripcion (si es menor de edad, vuelve a pedir los datos) -----
	Repetir
		mostrarTitulo("INSCRIPCION")
		nombre <- leerNombre()
		edad <- leerNumero("Edad: ", 1, 120, 0)

		Si edad < 18 Entonces
			mostrarTitulo("ACCESO DENEGADO")
			mostrarLinea("Tenes que ser mayor de 18 anios.")
			Escribir lineaDoble()
			aguardarTecla("Presiona una tecla para volver a intentar...")
		FinSi
	Hasta Que edad >= 18

	Limpiar Pantalla
	mostrarTitulo("ACCESO CONFIRMADO")
	mostrarLinea("Bienvenido/a " + Subcadena(nombre, 1, 21))
	Escribir lineaDoble()
	Escribir ""

	saldoInicial <- leerNumero("Elegi tu saldo inicial ($1000 - $10000): $", 1000, 10000, 0)
	saldo <- saldoInicial
	Limpiar Pantalla

	// ----- Menu -----
	Repetir
		mostrarTitulo("MENU PRINCIPAL")
		mostrarLinea("Saldo: $" + dinero(saldo))
		Escribir lineaSimple()
		mostrarLinea("1) Dados")
		mostrarLinea("2) Tragamonedas")
		mostrarLinea("3) Ruleta")
		mostrarLinea("0) Salir")
		Escribir lineaDoble()
		seleccion <- leerNumero("Elegi una opcion: ", 0, 3, 0)
		Limpiar Pantalla

		Si seleccion <> 0 Entonces
			Segun seleccion Hacer
				1: resultado <- jugarDados(saldo)
				2: resultado <- jugarTragamonedas(saldo)
				3: resultado <- jugarRuleta(saldo)
			FinSegun
			Si resultado = 1000000000 Entonces
				// se arrepintio: vuelve al menu sin jugar
				Limpiar Pantalla
			Sino
				saldo <- saldo + resultado
				total[seleccion] <- total[seleccion] + resultado
				jugadas[seleccion] <- jugadas[seleccion] + 1
				Escribir ""
				Escribir "  Saldo actual: $", dinero(saldo)
				aguardarTecla("Presiona una tecla para continuar...")

				Si saldo < 1 Entonces
					mostrarTitulo("SIN SALDO")
					mostrarLinea("Te quedaste sin saldo, no podes")
					mostrarLinea("seguir jugando.")
					Escribir lineaDoble()
					Escribir ""
					seleccion <- 0
				FinSi
			FinSi
		FinSi
	Hasta Que seleccion = 0

	// ----- Comprobante final -----
	mostrarComprobante(nombre, saldo, jugadas, total)
	Escribir ""
	Escribir "  Gracias por jugar. Hasta pronto!"

	aguardarTecla("Presiona una tecla para salir...")
FinAlgoritmo
